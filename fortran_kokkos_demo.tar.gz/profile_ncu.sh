#!/usr/bin/env bash
# Example: ncu --set full --target-processes all --csv --log-file outputs/ncu.csv "$@"
echo "NCU profiling stub (install Nsight Compute to enable)."
