#!/usr/bin/env bash
# Example: rocprof --stats -o outputs/rocprof.json "$@"
echo "rocprof stub (install ROCm tools to enable)."
